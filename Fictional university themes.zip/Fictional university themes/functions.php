<?php
function university_files(){
  wp_enqueue_script('main-university-js',get_theme_file_uri('/js/scripts-bundled.js',NULL,'1.0',true));
  wp_enqueue_style('custom-google-fonts','//fonts.googleapis.com/css?family=Roboto+Condensed:300,300i,400,400i,700,700i|Roboto:100,300,400,400i,700,700i');
    wp_enqueue_style('font-awesome','//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');
  wp_enqueue_style('university_main_styles',get_stylesheet_uri());

}


add_action('wp_enqueue_scripts','university_files');
// function theme_styles()
// {
//
// 	// Example of loading a jQuery slideshow plugin just on the homepage
// 	wp_register_style( 'flexslider', get_template_directory_uri() . '/css/flexslider.css' );
//
// 	// Load all of the styles that need to appear on all pages
// 	wp_enqueue_style( 'main', get_template_directory_uri() . '/style.css' );
// 	wp_enqueue_style( 'custom', get_template_directory_uri() . '/css/custom.css' );
//
// 	// Conditionally load the FlexSlider CSS on the homepage
// 	if(is_page('home')) {
// 		wp_enqueue_style('flexslider');
// 	}
//
// }
// add_action('wp_enqueue_scripts', 'theme_styles');
?>
