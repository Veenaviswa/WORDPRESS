<?php
$city_name=array("kolkata","Asansol","Siliguri","Durgapur","Bardhaman","Durgapur","Bardhaman","Dankuni","Ajmer")

 $arrlength=count($city_name);
 for($x=0;$x<$arrlenth;$x++)
 {
   echo $city_name[$x];
   echo "<br>";
 }
 ?>
